using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AgriChainDrivers;
using AgriChainPages;

namespace AgriChainTest
{
    public class AgriChainTest1 : BaseTest
    {
        private AgriChain agriChain;

        [SetUp]
        public void TestSetup()
        {
            
            driver.Navigate().GoToUrl("https://agrichain.com/qa/input");  
            agriChain = new AgriChain(driver);
        }

        [Test]
        public void NavigationToOutputScreen()
        {
            

            if (agriChain.agriChainHeader.Text.Contains("input"))
            {
                Console.WriteLine("User is Navigated to Correct Screen");

            }
            else
            {
                Console.WriteLine("User is Navigated to Different Screen");
            }
            agriChain.EnterString("aadditiad");
            agriChain.ClickSubmit();
            Assert.IsTrue(driver.Url.Contains("output"), "URL does not contain 'output'");

        }
    }
}
