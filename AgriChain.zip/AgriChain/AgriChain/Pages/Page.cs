﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgriChainPages
{
    public class AgriChain
    {
        private readonly IWebDriver driver;

        public AgriChain(IWebDriver driver)
        {
            this.driver = driver;
        }

        public IWebElement agriChainHeader => driver.FindElement(By.Id("agrichaintext"));
        public IWebElement inputField => driver.FindElement(By.ClassName("inputfield"));
        public IWebElement submitButton => driver.FindElement(By.XPath("//div[@Id='submitbutton']"));



        public void EnterString(string inputString)
        {
            inputField.Clear();
            inputField.SendKeys(inputString);
        }

        public void ClickSubmit()
        {
            submitButton.Click();
        }
    }
}
